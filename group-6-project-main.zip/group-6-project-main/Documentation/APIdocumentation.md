


# Group 6 Project Documentation

## Introduction

This Documentation provides an overview of theGroup 6 Project REST API, its purpose, and the general use cases. This repository currently contains an API specification (in root folder) in OpenAPI 3.x format


## Application Deployment

1. **Docker Installation**: Ensure Docker is installed. Refer to guides for [Windows](https://docs.docker.com/desktop/windows/install/), [Mac](https://docs.docker.com/desktop/mac/install/), [FreeBSD](https://wiki.freebsd.org/Docker), [Ubuntu](https://docs.docker.com/engine/install/ubuntu/), and other Linux distributions.
2. **Docker Compose**: On Linux, install Docker Compose separately ([installation guide](https://docs.docker.com/compose/install/linux/)).
3. **Version Checks**:
    - Run `docker --version` (requires version >=19.03).
4. **Configuration File**:
    - Modify the  `.env` file and it's settings as needed, especially ports to avoid conflicts (e.g., default Mongodb port 3000). If it does not work, modify the docker-compose.yml directly
5. **Running the Application**:
    - Use `docker compose up` in the project's root directory. If you want to run in detached mode, see the below example:

```shell    
docker-compose up -d    
```    


## Accessing the applications

After initializing the docker container, you can now access the user-friendly frontend simply by navigating to `localhost:3000` in any browser, where `3000` is the port specified in `.env` file or .`docker-compose.yml` For the backend it is `localhost:8080`.


## Schema

All API access are against the domain specified in .env or .docker-compose.yml

All API responses are in JSON format.or CSV format.

If not specified, POST, PUT, UPDATE, DELETE requests are sent in JSON format format by default. The content-type of the request must be set to application/json in this case. text/csv are also accepted, for requesting a CSV format response.

## How the configuration works

For those interested, here is a quick explanation of how the configuration in the `.env` file is propagated to the applications. The settings in the `.env` file get picked up by Docker Compose, where they will be passed on to environment variables for the applications. Both backends take these environment variables and use them for their runtime configuration.

# API Endpoints


### Overview
This API provides endpoints to manage and retrieve environmental data related to GDP, population, emissions, and climate change metrics for different countries and continents.

### Endpoints

1. **Get Population GDP Data**
    - **Description**: Retrieves GDP and population data for a specific country and year.
    - **Access**: `GET /countries/{countryIdentifier}/data/{year}`
    - **Request Representation**: Accept header for desired response format (JSON or CSV). Requires countryIdentifier and year, For example:
```html    
GET http://localhost:8080/countries/Netherlands/data/2000    
```    
would translate into this JSON request:
```json    
{    
   "gdp":6.03576139776E11,    
   "country_name":"Netherlands",    
   "iso_code":"NLD",    
   "population":15899138    
}    
```    
- **Response Representation**: Population GDP Data in JSON or CSV format, depends on Content-Type `application/json` or `text/csv`.
- **Errors**:
    - `404 Not Found`: If the location data is not found.
    - `204 No Content`: If there's no data for the given year.
    - `400 Bad Request`: If the population or GDP data is invalid.

2. **Put Population GDP Data**
    - **Description**: Updates GDP and population data for a specific country and year.
    - **Access**: `PUT /countries/{countryIdentifier}/data/{year}`
    - **Request Representation**: JSON object with `population` and `gdp` values. For example:
```html    
PUT http://localhost:8080/countries/Netherlands/data/2000    
```    
would update the data in the database, and translate into this JSON request:
```json    
{    
   "gdp":6.03576139776E11,    
   "country_name":"Netherlands",    
   "iso_code":"NLD",    
   "population":15899138    
}    
```    
- **Response Representation**: Returns updated data in JSON format, depends on Content-Type `application/json` or `text/csv`.
- **Errors**:
    - `404 Not Found`: If the location data is not found.

3. **Post Population GDP Data**
    - **Description**: Adds new GDP and population data for a specific country and year.
    - **Access**: `POST /countries/{countryIdentifier}/data/{year}`
    - **Request Representation**: JSON object with `population` and `gdp` values. For example:
```html    
POST http://localhost:8080/countries/Netherlands/data/2000    
```    
would create new data in the database, and translate into this JSON request:
```json    
{    
   "gdp":6.03576139776E11,    
   "country_name":"Netherlands",    
   "iso_code":"NLD",    
   "population":15899138    
}    
```    
- **Response Representation**: Returns the newly added data in JSON format., depends on Content-Type `application/json` or `text/csv`.
- **Errors**:
    - `404 Not Found`: If the location data is not found.

4. **Delete Population GDP Data**
    - **Description**: Deletes specific GDP and population data for a given country and year.
    - **Access**: `DELETE /countries/{countryIdentifier}/data/{year}`
    - **Request Representation**: Requires countryIdentifier and year. For example:
```html    
DELETE http://localhost:8080/countries/Netherlands/data/2000    
```    
would delete the requested data in the database, and translate into this JSON request:
```json    
{    
   "gdp":6.03576139776E11,    
   "country_name":"Netherlands",    
   "iso_code":"NLD",    
   "population":15899138    
}    
```    
- **Response Representation**: Returns a confirmation message, depends on Content-Type `application/json` or `text/csv`.
- **Errors**:
    - `404 Not Found`: If the specified location or year data is not found.

5. **Get Emissions Data**
    - **Description**: Retrieves emissions data for a specific country and year.
    - **Access**: `GET /countries/{countryIdentifier}/data/{year}/emissions`
    - **Request Representation**: Accept header for desired response format (JSON or CSV). For example:
```html    
GET http://localhost:8080/countries/Netherlands/data/2000/emissions    
```    
would delete the requested data in the database, and translate into this JSON request:
```json    
{    
   "co2":171.0822296142578,    
   "nitrous_oxide":14.319999694824219,    
   "total_ghg":207.39999389648438,    
   "country_name":"Netherlands",    
   "methane":23.18000030517578,    
   "iso_code":"NLD"    
}    
```    
- **Response Representation**: Emissions data in JSON or CSV format, depends on Content-Type `application/json` or `text/csv`.
- **Errors**:
    - `404 Not Found`: If the location data is not found.
    - `204 No Content`: If emissions data is not available for the year.

6. **Get Continent Temperature Change**
    - **Description**: Retrieves temperature change data for a continent from a specified year.
    - **Access**: `GET /continents/{continent}/temperature-change`
    - **Request Representation**: Query parameters for `from_year` and `Accept` header. For example:
```html    
GET http://localhost:8080/countries/Netherlands/data/2000/emissions    
```    
would delete the requested data in the database, and translate into this JSON request:
```json    
{    
   "co2":171.0822296142578,    
   "nitrous_oxide":14.319999694824219,    
   "total_ghg":207.39999389648438,    
   "country_name":"Netherlands",    
   "methane":23.18000030517578,    
   "iso_code":"NLD"    
}    
```    
- **Response Representation**: Data in JSON or CSV format, depends on Content-Type `application/json` or `text/csv`.
- **Errors**:
    - `404 Not Found`: If the continent data is not found.
    - `204 No Content`: If data for the specified years is not available.

7. **Get All Energy Data**
    - **Description**: Retrieves energy per capita and per GDP data for all countries in a    
      given year. Population size are sorted. Please refer the batch size as below:
```    
Small: 10    
Medium: 20    
Big: 50    
Large: 100    
```    
- **Access**: `GET /countries/energy/{year}?batchize={batchize}&offset={offset}`
- **Request Representation**:  For example:
```html    
http://localhost:8080/countries/energy/2000?batchize=10&offset=0    
```    
would translate into this JSON request:
```json    
[    
   {    
      "country_name":"China",    
      "energy_per_capita":9334.936,    
      "iso_code":"CHN",    
      "energy_per_gdp":1.9823471,    
      "population":1264099072    
   },    
   {    
      "country_name":"India",    
      "energy_per_capita":3518.6821,    
      "iso_code":"IND",    
      "energy_per_gdp":1.3444754,    
      "population":1059633664    
   },    
   {    
      "country_name":"United States",    
      "energy_per_capita":93999.86,    
      "iso_code":"USA",    
      "energy_per_gdp":2.046073,    
      "population":282398560    
   },    
   {    
      "country_name":"Indonesia",    
      "energy_per_capita":5435.4355,    
      "iso_code":"IDN",    
      "energy_per_gdp":1.0222057,    
      "population":214072416    
   },    
   {    
      "country_name":"Brazil",    
      "energy_per_capita":13400.32,    
      "iso_code":"BRA",    
      "energy_per_gdp":1.3587639,    
      "population":175873712    
   },    
   {    
      "country_name":"Pakistan",    
      "energy_per_capita":3133.7341,    
      "iso_code":"PAK",    
      "energy_per_gdp":1.0521005,    
      "population":154369920    
   },    
   {    
      "country_name":"Russia",    
      "energy_per_capita":49127.297,    
      "iso_code":"RUS",    
      "energy_per_gdp":4.683006,    
      "population":146844848    
   },    
   {    
      "country_name":"Bangladesh",    
      "energy_per_capita":1053.6212,    
      "iso_code":"BGD",    
      "energy_per_gdp":0.6777903,    
      "population":129193336    
   },    
   {    
      "country_name":"Japan",    
      "energy_per_capita":49229.383,    
      "iso_code":"JPN",    
      "energy_per_gdp":1.4808205,    
      "population":126803864    
   },    
   {    
      "country_name":"Nigeria",    
      "energy_per_capita":1827.2556,    
      "iso_code":"NGA",    
      "energy_per_gdp":0.8372037,    
      "population":122851984    
   }    
]    
```    
- **Response Representation**: Energy data in JSON or CSV format, depends on Content-Type `application/json` or `text/csv`.
- **Errors**:
    - `400 Bad Request`: If the batch size is not supported. Please refer to the batch size above.
    - `204 No Content`: If there's no data available.

8. **Get Climate Change Ranking**
    - **Description**: Retrieves climate change ranking based on greenhouse gas emissions from a range of years (optional)
    - **Access**: `GET /climate-change-ranking`
    - **Request Representation**: Query parameters for `rankType`, `countriesN`, `year`, `prevYears`, and `Accept` header.
    -
    - **Response Representation**: Ranking data in JSON or CSV format, depends on Content-Type `application/json` or `text/csv`.
    - **Errors**:
        - `404 Not Found`: If data is not available for the specified parameters.
        - `204 No Content`: If there are no countries to display in the ranking.

# Distribution of work among group members and the role(s) that each member performed.
- [Petre-Teodor Mocanu]: Teo significantly contributed the Frontend Development and User Experience Design. He crafted a robust interface.
- [Menno Dijksterhuis]: Menno made substantial contributions to the Backend Development and database integration.
- [Sheung Yin Jonathan Yeung]: Jonathan worked extensively with Docker and documentations. He made things hassle-free and clear.  
  Each of us contributed a good part of it.


# Reason Why we chose Java Spring + React (Node.js) + Typescript
- Maturity: Java Spring is a mature framework. With tremendous amount of people using it and a well established history, it is easy to find help and support.
- Scalability: With Node.js it is very easy to find packages we need, since it is known for its modularity.
- Love: We love the concept and philosophy of Java.

# How they fulfill all the requirements
- Simplicity: It is straightforward to add modules to it. For example, MongoDB with Spring are very easy to integrate. Few lines of code does their job.
- Type Safety: Syntactic Sugar, static typing etc... all are superior to Javascript, which reduces our time running into issues.

# The level of maturity of your RESTful API and any potential issues with it?
- We implemented CRUD operations for the API. It is fully functional and with straightforward instructions.
- Security: Our frontend is still using HTTP, which is vulnerable to MITM attacks, credentials are sent in clear over the network. Lack of authentication and authorization means that anyone discovered our website can even remove the database since we initialize the database with empty username and password.
- It was troublesome that we ran into issues where the selected options in the frontend differed from what we received in backend.
