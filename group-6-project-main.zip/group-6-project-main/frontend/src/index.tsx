import * as React from "react";
import * as ReactDOM from "react-dom";
import FirstComponent from "./FirstComponent.tsx";
import { createRoot } from "react-dom/client";
import { StrictMode } from "react";

const rootElement = document.getElementById("root");
const root = createRoot(rootElement);

const author: string = "Group 6";

const styles: React.CSSProperties = {
  container: {
    textAlign: "center",
    fontFamily: "Arial, sans-serif",
  },
  heading: {
    fontSize: "2em",
    color: "#000119",
  },
  authorInfo: {
    fontStyle: "italic",
    color: "#CCB700",
  },
  logo: {
      maxWidth: "150px",
    },
};

root.render(
  <StrictMode>
  <div style={styles.container}>
    <h1 style={styles.heading}>
      Data on CO2 and Greenhouse Gas
      <img src="https://upload.wikimedia.org/wikipedia/en/3/37/University_of_Groningen_coat_of_arms.png" alt="Logo" style={styles.logo} />
       Emissions by Our World in Data
    </h1>
    <p style={styles.authorInfo}>Author: {author} </p>
    <FirstComponent />
  </div>
  </StrictMode>
);


