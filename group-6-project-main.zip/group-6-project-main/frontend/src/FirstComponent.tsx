import React, { useState, useEffect } from "react";

const FirstComponent: React.FC<{}> = () => {
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [requestType, setRequestType] = useState<string>("");
  const [batchNumber, setBatchNumber] = useState<number>(0);
  const [gdp, setGdp] = useState<string>("");
  const [population, setPopulation] = useState<string>("");
  const [selectedMethodType, setSelectedMethodType] = useState<string>("");

  useEffect(() => {
    fetchData();
  }, [batchNumber]);

  const handleRequestMethodChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
      setSelectedMethodType(event.target.value);
    };

  const handleRequestTypeChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRequestType(event.target.value);
  };

  const handleNextBatch = () => {
    setBatchNumber((prevBatchNumber) => prevBatchNumber + 1);
  };

  const fetchData = async () => {
      try {
        setIsLoading(true);
        let endpoint = "";
        if (requestType === "PopulationGDP") {
          const country_id = (document.getElementById("country_id") as HTMLInputElement).value;
          const year = (document.getElementById("year") as HTMLInputElement).value;
          // var since method_type is needed outside of the if scope
          var method_type = (document.getElementById("method_type") as HTMLInputElement).value;

          endpoint = `http://localhost:8080/countries/${country_id}/data/${year}`;
        } else if (requestType === "EmissionsData") {
          const country_id = (document.getElementById("country_id") as HTMLInputElement).value;
          const year = (document.getElementById("year") as HTMLInputElement).value;

          endpoint = `http://localhost:8080/countries/${country_id}/data/${year}/emissions`;
        } else if (requestType === "TemperatureChange") {
          const continent = (document.getElementById("continent") as HTMLInputElement).value;
          const year = (document.getElementById("year") as HTMLInputElement).value;

          endpoint = `http://localhost:8080/continents/${continent}/temperature-change?from_year=${year}`;
        } else if (requestType === "EnergyData") {
           const year = (document.getElementById("year") as HTMLInputElement).value;
           const batch_size_option = (document.getElementById("batch_size") as HTMLInputElement).value;
           const batchSizesMap = {
             "small": 10,
             "medium": 20,
             "big": 50,
             "large": 100
           };

           const batchSize = batchSizesMap[batch_size_option];

           endpoint = `http://localhost:8080/countries/energy/${year}?batchSize=${batchSize}&offset=${batchNumber}`;

           const response = await fetch(endpoint, {
             method: method_type,
             headers: {
               "Content-Type": content_type,
               "Accept": accept_type
             }
           });

        } else if (requestType === "ClimateRanking") {
           const year = (document.getElementById("year") as HTMLInputElement).value;
           const previous_year = (document.getElementById("previous_year") as HTMLInputElement).value;
           const type = (document.getElementById("type") as HTMLInputElement).value;
           const number = (document.getElementById("number") as HTMLInputElement).value;

           endpoint = `http://localhost:8080/climate-change-ranking?rankType=${type}&countriesN=
           ${number}&year=${year}&prevYears=${previous_year}`;
        }

        if (endpoint) {
          var content_type = "application/json";
          var accept_type = "application/json";
          if (!(method_type === "PUT" || method_type === "POST") && (document.getElementById("is_csv") as HTMLInputElement).checked) {
            content_type = "text/csv";
            accept_type = "text/csv";
          }

          const requestBody = { gdp: gdp, population: population };

          const requestOptions = {
            method: method_type,
            headers: {
              "Content-Type": content_type,
              "Accept" : accept_type}
          };

          // request body for gdp and population values to put in database
          if (method_type === "PUT" || method_type === "POST" || method_type === "DELETE" ) {
            requestOptions.body = JSON.stringify(requestBody);
            content_type = "application/json";
            accept_type = "application/json";
          }

          const response = await fetch(endpoint, requestOptions);

          if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`HTTP error! Status: ${response.status}, ${errorText}`);
          }

          if (content_type === "text/csv" &&( method_type !== "PUT" && method_type !== "POST" &&
          method_type !== "DELETE")) {
            setData(await response.text());
          } else {
            setData(JSON.stringify(await response.json(), null, 2));
          }

          setError();
        }
      } catch (error) {
        console.error('Error fetching data:', error.message);
        setError(error.message || 'An error occurred while fetching data.');
      } finally {
        setIsLoading(false);
      }
    };

  return (
    <div>
      <div>
        <input
          type="radio"
          id="PopulationGDP"
          name="requestType"
          value="PopulationGDP"
          checked={requestType === "PopulationGDP"}
          onChange={handleRequestTypeChange}
        />
        <label htmlFor="PopulationGDP">PopulationGDP</label>

        <input
          type="radio"
          id="EmissionsData"
          name="requestType"
          value="EmissionsData"
          checked={requestType === "EmissionsData"}
          onChange={handleRequestTypeChange}
        />
        <label htmlFor="EmissionsData">EmissionsData</label>

        <input
          type="radio"
          id="TemperatureChange"
          name="requestType"
          value="TemperatureChange"
          checked={requestType === "TemperatureChange"}
          onChange={handleRequestTypeChange}
        />
        <label htmlFor="TemperatureChange">TemperatureChange</label>

        <input
          type="radio"
          id="EnergyData"
          name="requestType"
          value="EnergyData"
          checked={requestType === "EnergyData"}
          onChange={handleRequestTypeChange}
        />
        <label htmlFor="EnergyData">EnergyData</label>

        <input
          type="radio"
          id="ClimateRanking"
          name="requestType"
          value="ClimateRanking"
          checked={requestType === "ClimateRanking"}
          onChange={handleRequestTypeChange}
        />
        <label htmlFor="ClimateRanking">ClimateRanking</label>
      </div>

     {requestType === "PopulationGDP" && (
             <div>
               <label htmlFor="method_type">Select Method:</label>
               <select id="method_type" onChange={handleRequestMethodChange}>
                 <option value="GET">get</option>
                 <option value="PUT">put</option>
                 <option value="POST">post</option>
                 <option value="DELETE">delete</option>
               </select>
               <input type="text" id="country_id" placeholder="Enter Country ID" />
               <input type="text" id="year" placeholder="Enter Year" />


               {(selectedMethodType === "PUT" || selectedMethodType === "POST") && (
                 <div>
                   <label htmlFor="gdp">Enter GDP:</label>
                   <input
                     type="text"
                     id="gdp"
                     value={gdp}
                     onChange={(e) => setGdp(e.target.value)}
                     placeholder="Enter GDP"
                   />
                   <label htmlFor="population">Enter Population:</label>
                   <input
                     type="text"
                     id="population"
                     value={population}
                     onChange={(e) => setPopulation(e.target.value)}
                     placeholder="Enter Population"
                   />
                 </div>
               )}
             </div>
           )}

      {requestType === "EmissionsData" && (
        <div>
          <input type="text" id="country_id" placeholder="Enter Country ID" />
          <input type="text" id="year" placeholder="Enter Year" />
        </div>
      )}

      {requestType === "TemperatureChange" && (
        <div>
          <input type="text" id="continent" placeholder="Enter Continent ID" />
          <input type="text" id="year" placeholder="Enter Year" />
        </div>
      )}
      {requestType === "EnergyData" && (
        <div>
          <button onClick={handleNextBatch}>Next Batch</button>
          <input type="text" id="year" placeholder="Enter Year" />
          <label htmlFor="batch_size">Select Batch Size:</label>
          <select id="batch_size">
            <option value="small">Small</option>
            <option value="medium">Medium</option>
            <option value="big">Big</option>
            <option value="large">Large</option>
          </select>
        </div>
      )}

      {requestType === "ClimateRanking" && (
        <div>
          <label htmlFor="type">Select Ranking Type:</label>
          <select id="type">
            <option value="top">Top</option>
            <option value="bottom">Bottom</option>
            </select>
          <input type="text" id="number" placeholder="Enter Number of Countries" />
          <input type="text" id="year" placeholder="Enter Year" />
          <input type="text" id="previous_year" placeholder="Enter Previous Year" />
        </div>
      )}

     <button onClick={fetchData}>Execute</button>

     <input type="checkbox" id="is_csv" name="csv" value="csv" />
     <label htmlFor="is_csv">csv</label>

     {isLoading ? (
       <p>Loading...</p>
     ) : error ? (
       <div>Error: {error}</div>
     ) : data ? (
       <pre>
         <p>Result:</p>
         <p>{data}</p>
      </pre>
     ) : null}
    </div>
  );
};

export default FirstComponent;
