import json
import pprint


# needed in country:
# iso_code
# needed in data: 
# - per country - for the last 50 years -
# population
# gdp
# co2
# methane
# nitrous_oxide
# total_ghg
# share_of_temperature_change_from_* (per continent)
# temperature_change_from_* (per continent)
# energy_per_capita
# energy_per_gdp
# (again) share_of_temperature_change_from_ghg (top/bottom N)
#
# Also continents are present and continent(GCP) are presentz



wanted_data_id = ["population", 
               "gdp", 
               "co2", 
               "methane", 
               "nitrous_oxide", 
               "total_ghg",
               "energy_per_capita", 
               "energy_per_gdp",
               "share_of_temperature_change_from_ghg",
               "temperature_change_from_ch4",
               "temperature_change_from_co2",
               "temperature_change_from_ghg",
               "temperature_change_from_n2o"]

wanted_data_match_begin = ["share_of_temperature_change_from", "temperature_change_from",]

continents = ["Africa", "North America", "South America", "Europe", "Asia", "Oceania"]

with open('owid-co2-data.json', 'r') as f:
  allData = json.load(f)

trimmedData = {}


i = 0
for country in allData:
  country = country
  country_info = allData[country]

  trimmedData[country] = {}

  if "iso_code" not in country_info and not country in continents:
    continue

  trimmedData[country]["isContinent"] = country in continents
  if "iso_code" in country_info:
    trimmedData[country]["iso_code"] = country_info["iso_code"]
  trimmedData[country]["data"] = []


  for year_data in country_info.get("data"):
    if year_data.get("year") >= 2023 - 50:
      trimmedYearData = {"year" : year_data.get("year")}

      for id in wanted_data_id:
        if id in year_data:

          if country not in continents and id in ["temperature_change_from_ch4", "temperature_change_from_co2", "temperature_change_from_ghg", "temperature_change_from_n2o"]:
            continue
          trimmedYearData[id] = year_data[id]
      
      trimmedData[country]["data"].append(trimmedYearData)


with open('trimmedData.json', 'w') as f:
    # f.write(pprint.pformat(trimmedData).replace("'", '"')) # use double quotes
  json.dump(trimmedData, f)
  