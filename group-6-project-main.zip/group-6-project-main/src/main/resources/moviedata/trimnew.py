import json
import argparse
import datetime


# ISSUES: Country name not showing, instead iso-code is shown.
#         Code will ignore Continent data.

# needed in country:
# iso_code
# needed in data:
# - per country - for the last 50 years -
# RCUD = ["population", "gdp"]
# MinRead = ["co2", "methane", "nitrous_oxide", "total_ghg"]
# share_of_temperature_change_from_* (per continent)
# temperature_change_from_* (per continent)
# energy_per_capita
# energy_per_gdp
# (again) share_of_temperature_change_from_ghg (top/bottom N)
#
# Also continents are present and continent(GCP) are present
# Needed in arguments:
# provided year， print year to the newest year;

class Config:
    iso_code = 'iso_code'
    data = 'data'
    year = 'year'


# TODO: read from file instead
# Should only use what specified
WANTED_DATA_FIELDS = [Config.year, 'population', 'gdp', 'cement_co2',
                      'cement_co2_per_capita', 'co2',
                      'co2_growth_abs',
                      'co2_growth_prct', 'co2_including_luc', 'co2_including_luc_growth_abs',
                      'co2_including_luc_growth_prct',
                      'co2_including_luc_per_capita', 'co2_including_luc_per_gdp', 'co2_including_luc_per_unit_energy',
                      'co2_per_capita', 'co2_per_gdp', 'co2_per_unit_energy', 'coal_co2', 'coal_co2_per_capita',
                      'consumption_co2',
                      'consumption_co2_per_capita', 'consumption_co2_per_gdp', 'cumulative_cement_co2',
                      'cumulative_co2',
                      'cumulative_co2_including_luc', 'cumulative_coal_co2', 'cumulative_flaring_co2',
                      'cumulative_gas_co2',
                      'cumulative_luc_co2', 'cumulative_oil_co2', 'cumulative_other_co2', 'energy_per_capita',
                      'energy_per_gdp',
                      'flaring_co2', 'flaring_co2_per_capita', 'gas_co2', 'gas_co2_per_capita',
                      'ghg_excluding_lucf_per_capita',
                      'ghg_per_capita', 'land_use_change_co2', 'land_use_change_co2_per_capita', 'methane',
                      'methane_per_capita',
                      'nitrous_oxide', 'nitrous_oxide_per_capita', 'oil_co2', 'oil_co2_per_capita',
                      'other_co2_per_capita',
                      'other_industry_co2', 'primary_energy_consumption', 'share_global_cement_co2', 'share_global_co2',
                      'share_global_co2_including_luc', 'share_global_coal_co2', 'share_global_cumulative_cement_co2',
                      'share_global_cumulative_co2', 'share_global_cumulative_co2_including_luc',
                      'share_global_cumulative_coal_co2',
                      'share_global_cumulative_flaring_co2', 'share_global_cumulative_gas_co2',
                      'share_global_cumulative_luc_co2',
                      'share_global_cumulative_oil_co2', 'share_global_cumulative_other_co2',
                      'share_global_flaring_co2',
                      'share_global_gas_co2', 'share_global_luc_co2', 'share_global_oil_co2', 'share_global_other_co2',
                      'share_of_temperature_change_from_ghg', 'temperature_change_from_ch4',
                      'temperature_change_from_co2',
                      'temperature_change_from_ghg', 'temperature_change_from_n2o', 'total_ghg',
                      'total_ghg_excluding_lucf',
                      'trade_co2', 'trade_co2_share']

# TODO Should use the largest year in the dataset instead
CURRENT_YEAR = datetime.date.today().year
YEARS_TO_USE = 5000  # for testing, should be 50


# def filter_iso(trimmed_data, requested_iso_codes):
#     filtered_data = {}
#     for iso_code in requested_iso_codes:
#         if iso_code in trimmed_data:
#             filtered_data[iso_code] = trimmed_data[iso_code]
#     return filtered_data


def read_json(file_path):
    with open(file_path, 'r') as f:
        return json.load(f)


def write_json(data, file_path, is_minified):
    with open(file_path, 'w') as f:
        if is_minified:
            json.dump(data, f, separators=(
                ',', ':'))  # https://stackoverflow.com/questions/33233313/python-json-dumpsval-to-output-minified-json
        else:
            json.dump(data, f, indent=4)


def process_data(all_data):
    trimmed_data = {}

    for country in all_data:
        country_info = all_data[country]

        iso_codes = country_info.get(Config.iso_code)
        if iso_codes:
            # Check if the iso_codes key is already present in trimmed_data
            if iso_codes not in trimmed_data:
                trimmed_data[iso_codes] = {}
                trimmed_data[iso_codes][Config.iso_code] = iso_codes
                trimmed_data[iso_codes][Config.data] = []

            for year_data in country_info.get(Config.data, []):
                if year_data.get(Config.year, 0) >= CURRENT_YEAR - YEARS_TO_USE:
                    trimmed_year_data = {Config.year: year_data.get(Config.year)}

                    for id in WANTED_DATA_FIELDS:
                        if id in year_data:
                            trimmed_year_data[id] = year_data[id]

                    trimmed_data[iso_codes][Config.data].append(trimmed_year_data)

    return trimmed_data


def main():
    parser = argparse.ArgumentParser(description='Json trimmer')
    # parser.add_argument('-i', '--iso_codes', nargs='+',
    #                     help='Specify ISO codes to filter data. (If not provided, default is all.)')
    parser.add_argument('-m', '--min', action=argparse.BooleanOptionalAction, default=False,
                        help='Minify the output json if specified. (If not provided, default is false.)')

    args = parser.parse_args()

    all_data = read_json('owid-co2-data.json')
    trimmed_data = process_data(all_data)

    # if args.iso_codes:
    #     filtered_data = filter_iso(trimmed_data, args.iso_codes)
    # else:
    #     filtered_data = trimmed_data
    filtered_data = trimmed_data
    write_json(filtered_data, 'trimmedDataNEW.json', args.min)


if __name__ == "__main__":
    main()
