package com.example.emissions.model.json;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

// Class for temporarily storing data from the json, to be converted to YearData

@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class Year {
    @JsonProperty("year")
    private int year;

    @JsonProperty("population")
    private long population;

    @JsonProperty("energy_per_capita")
    private float energyPerCapita;

    @JsonProperty("energy_per_gdp")
    private float energyPerGdp;

    @JsonProperty("co2")
    private double co2;

    @JsonProperty("methane")
    private double methane;

    @JsonProperty("nitrous_oxide")
    private double nitrousOxide;

    @JsonProperty("total_ghg")
    private double totalGHG;

    @JsonProperty("gdp")
    private double gdp;

    @JsonProperty("share_of_temperature_change_from_ghg")
    private double shareTempChangeGhg;

    // below only for continents
    @JsonProperty("temperature_change_from_ch4")
    private double temperature_change_from_ch4;

    @JsonProperty("temperature_change_from_co2")
    private double temperature_change_from_co2;

    @JsonProperty("temperature_change_from_ghg")
    private double temperature_change_from_ghg;

    @JsonProperty("temperature_change_from_n2o")
    private double temperature_change_from_n2o;
}
