package com.example.emissions.model.json;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

import java.util.List;

// Class for temporarily storing data from the json, to be converted to LocationData

@Getter
public class Location {
    @JsonProperty("iso_code")
    private String ISO;

    @JsonProperty("isContinent")
    private boolean isContinent;

    @JsonProperty("data")
    private List<Year> yearList;
}
