package com.example.emissions.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class YearData {
    private float energy_per_capita;
    private float energy_per_gdp;
    private long population;
    private double gdp;
    private double co2;
    private double methane;
    private double nitrous_oxide;
    private double total_ghg;
    private double share_temp_change_ghg;
    private double temperature_change_from_ch4;
    private double temperature_change_from_co2;
    private double temperature_change_from_ghg;
    private double temperature_change_from_n2o;
}
