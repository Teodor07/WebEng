package com.example.emissions.endpoints;

import com.example.emissions.model.DataRepository;
import com.example.emissions.model.LocationData;
import com.example.emissions.model.YearData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class InteractDB {
    private final DataRepository repository;

    @Autowired
    public InteractDB(DataRepository repository) {
        this.repository = repository;
    }

    public LocationData getLocationData(String country) {
        LocationData locationData;

        if (country.length() == 3) {
            locationData = repository.findLocationByISO(country);
        } else {
            locationData = repository.findLocationByName(country);
        }

        return locationData;
    }

    public Map<String, Object> getLocationYearResponseData(LocationData locationData, int year) {
        YearData yearData = locationData.getYearData().get(year);
        Map<String, Object> responseData = new HashMap<>();
        responseData.put("iso_code", locationData.getISO());
        responseData.put("country_name", locationData.getName());
        responseData.put("population", yearData.getPopulation());
        responseData.put("gdp", yearData.getGdp());

        return responseData;
    }

    public Map<String, Object> getEmissionResponseData(LocationData locationData, int year) {
        YearData yearData = locationData.getYearData().get(year);
        Map<String, Object> responseData = new HashMap<>();
        responseData.put("iso_code", locationData.getISO());
        responseData.put("country_name", locationData.getName());
        responseData.put("co2", yearData.getCo2());
        responseData.put("methane", yearData.getMethane());
        responseData.put("nitrous_oxide", yearData.getNitrous_oxide());
        responseData.put("total_ghg", yearData.getTotal_ghg());

        return responseData;
    }


    public Map<String, Object> getContinentResponseData(LocationData locationData, int fromYear, int currentYear) {
        Map<String, Object> data = new HashMap<>();
        data.put("continent", locationData.getName());
        data.put("from_year", fromYear);
        data.put("to_year", currentYear);
        YearData fromYearData = locationData.getYearData().get(fromYear);
        YearData currentYearData = locationData.getYearData().get(currentYear);
        data.put("temperature_change", cTemperatureChange(fromYearData, currentYearData));

        return data;
    }

    public List<Map<String, Object>> getSortedCountryData(int year, int offset, int batchSize) {
        TreeMap<Pair<Long, String>, Map<String, Object>> sortedCountryData = new TreeMap<>(Comparator.comparing(Pair<Long, String>::getFirst).reversed().thenComparing(Pair<Long, String>::getSecond));

        repository.findAll().forEach(locationData -> {
            YearData yearData = locationData.getYearData().get(year);
            if (yearData != null && locationData.getISO() != null) {
                Map<String, Object> country = formatCountryData(locationData.getISO(), locationData.getName(), yearData.getEnergy_per_capita(), yearData.getEnergy_per_gdp(), yearData.getPopulation());
                sortedCountryData.put(Pair.of(yearData.getPopulation(), locationData.getISO()), country);
            }
        });

        return sortedCountryData.values().stream().skip(offset).limit(batchSize).collect(Collectors.toList());
    }

    private Map<String, Object> formatCountryData(String ISO, String countryName, float energyPerCapita, float energyPerGdp, long population) {
        Map<String, Object> countryData = new HashMap<>();
        countryData.put("iso_code", ISO);
        countryData.put("country_name", countryName);
        countryData.put("energy_per_capita", energyPerCapita);
        countryData.put("energy_per_gdp", energyPerGdp);
        countryData.put("population", population);
        return countryData;
    }

    public TreeMap<Double, Map<String, Object>>  getSortedShareGhg(String rankingType, int year, int prevYears) {
        TreeMap<Double, Map<String, Object>> sortedShareGhg = new TreeMap<>(
                rankingType.equals("top") ? Collections.reverseOrder() : Comparator.naturalOrder());

        repository.findAll().forEach(locationData -> {
            YearData yearData = locationData.getYearData().get(year);
            if (yearData != null && !locationData.isContinent()) {
                double shareChange = cShareChange(locationData, year, prevYears);
                Map<String, Object> country = new HashMap<>();
                country.put("iso_code", locationData.getISO());
                country.put("country_name", locationData.getName());
                country.put("share_of_temperature_change_from_ghg", shareChange);
                sortedShareGhg.put(shareChange, country);
            }
        });

        return sortedShareGhg;
    }

    private double cShareChange(LocationData locationData, int year, int prevYears) {
        double currentYearShare = locationData.getYearData().getOrDefault(year, new YearData()).getShare_temp_change_ghg();
        double previousYearsShareTotal = 0;

        for (int i = 1; i <= prevYears; i++) {
            YearData prevYearData = locationData.getYearData().getOrDefault(year - i, new YearData());
            previousYearsShareTotal += prevYearData.getShare_temp_change_ghg();
        }

        double averagePreviousYearsShare = prevYears > 0 ? previousYearsShareTotal / prevYears : 0;
        return currentYearShare - averagePreviousYearsShare;
    }

    public Map<String, Double> cTemperatureChange(YearData fromYearData, YearData currentYearData) {
        Map<String, Double> temperatureChange = new HashMap<>();
        temperatureChange.put("ch4", currentYearData.getTemperature_change_from_ch4() - fromYearData.getTemperature_change_from_ch4());
        temperatureChange.put("co2", currentYearData.getTemperature_change_from_co2() - fromYearData.getTemperature_change_from_co2());
        temperatureChange.put("ghg", currentYearData.getTemperature_change_from_ghg() - fromYearData.getTemperature_change_from_ghg());
        temperatureChange.put("n2o", currentYearData.getTemperature_change_from_n2o() - fromYearData.getTemperature_change_from_n2o());
        return temperatureChange;
    }

    public List<Map<String, Object>>  getClimateRankingBatch(TreeMap<Double, Map<String, Object>> sortedShareGhg, int countriesN) {
        if (sortedShareGhg.isEmpty()) {
            return null;
        }
        return sortedShareGhg.values().stream()
                .limit(countriesN)
                .collect(Collectors.toList());
    }

    public void updateLocationData(LocationData locationData) {
        repository.save(locationData);
    }

    public boolean deleteYearData(LocationData locationData, int year) {
        try {
            YearData yearData = locationData.getYearData().remove(year);
            updateLocationData(locationData);
            return true;
        }catch (Exception e){
            System.out.println(e);
        }
        return false;
    }
}
