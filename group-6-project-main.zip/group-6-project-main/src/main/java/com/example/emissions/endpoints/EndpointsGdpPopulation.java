package com.example.emissions.endpoints;

import com.example.emissions.model.DataRepository;
import com.example.emissions.model.LocationData;
import com.example.emissions.model.YearData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("")
public class EndpointsGdpPopulation {
    private final InteractDB interactDB;

    @Autowired
    public EndpointsGdpPopulation(DataRepository repository) {
        this.interactDB = new InteractDB(repository);
    }

    @DeleteMapping("/countries/{countryIdentifier}/data/{year}")
    public ResponseEntity<Map<String, String>> deletePopulationGDPData(
            @PathVariable("countryIdentifier") String countryIdentifier,
            @PathVariable("year") int year) {

        LocationData locationData = interactDB.getLocationData(countryIdentifier);
        // Check if location data is null
        if (locationData == null) {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body(Collections.singletonMap("message", "Location data not found for the country identifier " + countryIdentifier + "."));
        }

        YearData yearData = locationData.getYearData().get(year);
        Map<String, Object> responseData = interactDB.getLocationYearResponseData(locationData, year);

        // Check if year data is null
        if (yearData == null) {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body(Collections.singletonMap("message", "Year data not found for the location " + locationData.getName() + " and year " + year + "."));
        }

        boolean isDeleted = interactDB.deleteYearData(locationData, year);

        if (isDeleted) {
            return ResponseEntity
                    .ok()
                    .body(Collections.singletonMap("message", "Data successfully deleted for the year " + year + "."));
        } else {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body(Collections.singletonMap("message", "Year data not found for deletion."));
        }
    }

    @PutMapping("/countries/{countryIdentifier}/data/{year}")
    public ResponseEntity<Map<String, Object>> putPopulationGDPData(
            @RequestBody Map<String, Object> requestBody,
            @PathVariable("countryIdentifier") String countryIdentifier,
            @PathVariable("year") int year) {

        LocationData locationData = interactDB.getLocationData(countryIdentifier);

        long population = Long.parseLong(requestBody.get("population").toString());
        double gdp = Double.parseDouble(requestBody.get("gdp").toString());

        if (locationData != null) {
            // check if it exists to be updated
            if (population == 0L || gdp == 0D) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }

            // put updated values
            YearData yearData = locationData.getYearData().get(year);
            yearData.setPopulation(population);
            yearData.setGdp(gdp);

            interactDB.updateLocationData(locationData);

            Map<String, Object> responseData = interactDB.getLocationYearResponseData(locationData, year);

            return ResponseEntity.ok(responseData);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    @PostMapping("/countries/{countryIdentifier}/data/{year}")
    public ResponseEntity<Map<String, Object>> postPopulationGDPData(
            @RequestBody Map<String, Object> requestBody,
            @PathVariable("countryIdentifier") String countryIdentifier,
            @PathVariable("year") int year) {

        LocationData locationData = interactDB.getLocationData(countryIdentifier);

        long population = Long.parseLong(requestBody.get("population").toString());
        double gdp = Double.parseDouble(requestBody.get("gdp").toString());

        if (locationData != null) {
            YearData yearData = new YearData();
            yearData.setPopulation(population);
            yearData.setGdp(gdp);

            // add new yearData
            locationData.getYearData().put(year, yearData);

            interactDB.updateLocationData(locationData);

            Map<String, Object> responseData = interactDB.getLocationYearResponseData(locationData, year);

            return ResponseEntity.ok(responseData);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }
}