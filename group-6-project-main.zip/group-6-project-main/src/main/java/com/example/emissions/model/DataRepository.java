package com.example.emissions.model;

//import com.example.tutorial.model.GroceryItem;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import javax.xml.stream.Location;
import java.util.List;

public interface DataRepository extends MongoRepository<LocationData, String> {
    @Query("{name:'?0'}")
    LocationData findLocationByName(String name);

    @Query("{ISO:'?0'}")
    LocationData findLocationByISO(String ISO);
}
