package com.example.emissions.endpoints;

import com.example.emissions.JsonToCsv;
import com.example.emissions.model.DataRepository;
import com.example.emissions.model.LocationData;
import com.example.emissions.model.YearData;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Pair;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.emissions.JsonToCsv;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

// TODO: Add CSV return support.

@CrossOrigin
@RestController
@RequestMapping("")
public class EndpointsRetrieve {
    private final InteractDB interactDB;

    @Autowired
    public EndpointsRetrieve(DataRepository repository) {
        this.interactDB = new InteractDB(repository);
    }

    @GetMapping("/countries/{countryIdentifier}/data/{year}")
    public ResponseEntity<String> getPopulationGDPData(
            @PathVariable("countryIdentifier") String countryIdentifier,
            @PathVariable("year") int year,
            @RequestHeader(value = "Accept") String acceptHeader) {

        LocationData locationData = interactDB.getLocationData(countryIdentifier);

        if (locationData == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        YearData yearData = locationData.getYearData().get(year);

        if (yearData == null) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
        }

        long population = yearData.getPopulation();
        double gdp = yearData.getGdp();

        if (population == 0 || gdp == 0) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        Map<String, Object> responseData = interactDB.getLocationYearResponseData(locationData, year);

        // check the accept header and return CSV or JSON accordingly
        if (acceptHeader.equals("text/csv")) {
            // convert the response data to CSV string
            String csvData = null;
            try {
                JsonToCsv jsonToCsv = new JsonToCsv();
                csvData = jsonToCsv.toCsv(responseData);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            // set the content type and return the CSV data
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType("text/csv"))
                    .body(csvData);
        } else {
            // convert the response data to JSON string
            String jsonData = null;
            try {
                jsonData = new ObjectMapper().writeValueAsString(responseData);
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
            // set the content type and return the JSON data
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(jsonData);
        }
    }

    @GetMapping("/countries/{countryIdentifier}/data/{year}/emissions")
    public ResponseEntity<String> getEmissionsData(
            @PathVariable("countryIdentifier") String countryIdentifier,
            @PathVariable("year") int year,
            @RequestHeader(value = "Accept") String acceptHeader) {

        LocationData locationData = interactDB.getLocationData(countryIdentifier);

        if (locationData == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        YearData yearData = locationData.getYearData().get(year);

        if (yearData == null) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
        }

        Map<String, Object> responseData = interactDB.getEmissionResponseData(locationData, year);

        // check the accept header and return CSV or JSON accordingly
        if (acceptHeader.equals("text/csv")) {
            // convert the response data to CSV string
            String csvData = null;
            try {
                JsonToCsv jsonToCsv = new JsonToCsv();
                csvData = jsonToCsv.toCsv(responseData);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            // set the content type and return the CSV data
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType("text/csv"))
                    .body(csvData);
        } else {
            // convert the response data to JSON string
            String jsonData = null;
            try {
                jsonData = new ObjectMapper().writeValueAsString(responseData);
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
            // set the content type and return the JSON data
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(jsonData);
        }
    }

    @GetMapping("/continents/{continent}/temperature-change")
    public ResponseEntity<String> getContinentTemperatureChange(
            @PathVariable("continent") String continentName,
            @RequestParam(name = "from_year", required = false, defaultValue = "2000") int fromYear,
            @RequestHeader(value = "Accept") String acceptHeader) {

        LocationData locationData = interactDB.getLocationData(continentName);
        if (locationData == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        final int currentYear = 2021;

        YearData fromYearData = locationData.getYearData().get(fromYear);
        YearData currentYearData = locationData.getYearData().get(currentYear);
        if (fromYearData == null || currentYearData == null) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
        }

        Map<String, Object> data = interactDB.getContinentResponseData(locationData, fromYear, currentYear);

        // check the accept header and return CSV or JSON accordingly
        if (acceptHeader.equals("text/csv")) {
            // convert the response data to CSV string
            String csvData = null;
            try {
                JsonToCsv jsonToCsv = new JsonToCsv();
                csvData = jsonToCsv.toCsv(data);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            // set the content type and return the CSV data
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType("text/csv"))
                    .body(csvData);
        } else {
            // convert the response data to JSON string
            String jsonData = null;
            try {
                jsonData = new ObjectMapper().writeValueAsString(data);
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
            // set the content type and return the JSON data
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(jsonData);
        }
    }

    @GetMapping("/countries/energy/{year}")
    public ResponseEntity<String> getAllEnergy(
            @PathVariable("year") int year,
            @RequestParam(name = "batchSize", required = false, defaultValue = "10") int batchSize,
            @RequestParam(name = "offset", required = false, defaultValue = "0") int offset,
            @RequestHeader(value = "Accept") String acceptHeader) {

        // check batch size supported
        if (!Arrays.asList(10, 20, 50, 100).contains(batchSize)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        List<Map<String, Object>> batch = interactDB.getSortedCountryData(year, offset, batchSize);

        if (batch.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
        }

        // check the accept header and return CSV or JSON accordingly
        if (acceptHeader.equals("text/csv")) {
            // convert the response data to CSV string
            String csvData = null;
            try {
                JsonToCsv jsonToCsv = new JsonToCsv();
                csvData = jsonToCsv.toCsv(batch);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            // set the content type and return the CSV data
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType("text/csv"))
                    .body(csvData);
        } else {
            // convert the response data to JSON string
            String jsonData = null;
            try {
                jsonData = new ObjectMapper().writeValueAsString(batch);
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
            // set the content type and return the JSON data
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(jsonData);
        }
    }

    @GetMapping("/climate-change-ranking")
    public ResponseEntity<String> getClimateChangeRanking(
            @RequestParam(name = "rankType", required = false, defaultValue = "top") String rankingType,
            @RequestParam(name = "countriesN", required = false, defaultValue = "10") int countriesN,
            @RequestParam(name = "year", required = false, defaultValue = "2000") int year,
            @RequestParam(name = "prevYears", required = false, defaultValue = "1") int prevYears,
            @RequestHeader(value = "Accept") String acceptHeader) {

        TreeMap<Double, Map<String, Object>> sortedShareGhg = interactDB.getSortedShareGhg(rankingType, year, prevYears);

        if (sortedShareGhg.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        List<Map<String, Object>> batch = interactDB.getClimateRankingBatch(sortedShareGhg, countriesN);

        if (batch.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
        }

        // check the accept header and return CSV or JSON accordingly
        if (acceptHeader.equals("text/csv")) {
            // convert the response data to CSV string
            String csvData = null;
            try {
                JsonToCsv jsonToCsv = new JsonToCsv();
                csvData = jsonToCsv.toCsv(batch);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            // set the content type and return the CSV data
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType("text/csv"))
                    .body(csvData);
        } else {
            // convert the response data to JSON string
            String jsonData = null;
            try {
                jsonData = new ObjectMapper().writeValueAsString(batch);
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
            // set the content type and return the JSON data
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(jsonData);
        }
    }
}
