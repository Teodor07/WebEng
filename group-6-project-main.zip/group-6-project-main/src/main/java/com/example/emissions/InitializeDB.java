package com.example.emissions;

import com.example.emissions.model.DataRepository;
import com.example.emissions.model.LocationData;
import com.example.emissions.model.YearData;
import com.example.emissions.model.json.Location;
import com.example.emissions.model.json.Year;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;

@Slf4j
public class InitializeDB {
    private final DataRepository dataRepository;

    public InitializeDB(DataRepository dataRepository) {
        this.dataRepository = dataRepository;
    }

    public void readJSON() {
        String jsonPath = System.getProperty("user.dir") + "/src/main/resources/moviedata/trimmedData.json";

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, Location> locationMap = objectMapper.readValue(new File(jsonPath), new TypeReference<Map<String, Location>>() {});

            for (String locationString : locationMap.keySet()) {
                Location location = locationMap.get(locationString);

                Map<Integer, YearData> yearMap = new HashMap<>();
                if (location.getYearList() != null) {
                    for (Year year : location.getYearList()) {
                        yearMap.put(year.getYear(), convertToYearData(year));
                    }
                }
                LocationData locationData = new LocationData(locationString, location.getISO(), location.isContinent(), yearMap);
                dataRepository.save(locationData);
            }
        } catch (Exception e) {
            log.error("Error reading JSON", e);
        }
    }

    private YearData convertToYearData(Year year) {
        YearData yearData = new YearData();
        yearData.setEnergy_per_capita(year.getEnergyPerCapita());
        yearData.setEnergy_per_gdp(year.getEnergyPerGdp());
        yearData.setPopulation(year.getPopulation());
        yearData.setGdp(year.getGdp());
        yearData.setCo2(year.getCo2());
        yearData.setMethane(year.getMethane());
        yearData.setNitrous_oxide(year.getNitrousOxide());
        yearData.setTotal_ghg(year.getTotalGHG());
        yearData.setShare_temp_change_ghg(year.getShareTempChangeGhg());
        yearData.setTemperature_change_from_ch4(year.getTemperature_change_from_ch4());
        yearData.setTemperature_change_from_co2(year.getTemperature_change_from_co2());
        yearData.setTemperature_change_from_ghg(year.getTemperature_change_from_ghg());
        yearData.setTemperature_change_from_n2o(year.getTemperature_change_from_n2o());

        return yearData;
    }

    void createLocationData() {
        System.out.println("Data creation started...");
        Map<Integer, YearData> yearData = null; //test, empty
        dataRepository.save(new LocationData("Netherlands","NLD", FALSE, yearData));
        dataRepository.save(new LocationData("Europe","", TRUE, yearData));
        System.out.println("Data creation complete...");
    }
}
