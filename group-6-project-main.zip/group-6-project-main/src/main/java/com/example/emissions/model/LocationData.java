package com.example.emissions.model;

import lombok.Getter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Map;

@Getter
@Document("locationdata")
public class LocationData {
    @Id
    private final String name;
    private final String ISO;
    private final boolean isContinent;
    private final Map<Integer, YearData> yearData;

    public LocationData(String name, String ISO, boolean isContinent, Map<Integer, YearData> yearData) {
        this.name = name;
        this.ISO = ISO;
        this.isContinent = isContinent;
        this.yearData = yearData;
    }

//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        LocationData country = (LocationData) o;
//        return name.equals(country.name) &&
//                ISO.equals(country.ISO) &&
//                isContinent == country.isContinent &&
//                yearData.equals(country.yearData);
//    }
//
//    @Override
//    public String toString() {
//        return "LocationData{" +
//                "name='" + name + '\'' +
//                ", ISO='" + ISO + '\'' +
//                ", isContinent=" + isContinent +
//                ", yearData=" + yearData +
//                '}';
//    }
}
