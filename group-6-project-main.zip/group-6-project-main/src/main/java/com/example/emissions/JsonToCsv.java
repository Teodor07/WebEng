package com.example.emissions;

import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class JsonToCsv {
    private static final CsvMapper csvMapper = new CsvMapper();

//    public String toCsv(Map<String, Object> data) throws IOException {
//        StringWriter writer = new StringWriter();
//
//        if (data != null && !data.isEmpty()) {
//            Set<String> columnNames = data.keySet();
//
//            CsvSchema schema = CsvSchema.builder()
//                    .addColumns(columnNames, CsvSchema.ColumnType.STRING)
//                    .build()
//                    .withHeader();
//
//            csvMapper.writer(schema).writeValue(writer, data);
//        }
//
//        return writer.toString();
//    }

    public String toCsv(Map<String, Object> data) throws IOException {
        StringWriter writer = new StringWriter();

        if (data != null && !data.isEmpty()) {
            Map<String, String> flattenedMap = flattenMap(data);

            CsvSchema schema = CsvSchema.builder()
                    .addColumns(flattenedMap.keySet(), CsvSchema.ColumnType.STRING)
                    .build()
                    .withHeader();

            csvMapper.writer(schema).writeValue(writer, flattenedMap);
        }

        return writer.toString();
    }

    // recursively make the json non recursive
    private Map<String, String> flattenMap(Map<String, Object> data) {
        Map<String, String> flattenedMap = new HashMap<>();

        for (Map.Entry<String, Object> entry : data.entrySet()) {
            if (entry.getValue() instanceof Map) {
                Map<String, String> nestedMap = flattenMap((Map<String, Object>) entry.getValue());
                nestedMap = addPrefixToKeys(nestedMap, entry.getKey() + ".");
                flattenedMap.putAll(nestedMap);
            } else {
                flattenedMap.put(entry.getKey(), entry.getValue().toString());
            }
        }

        return flattenedMap;
    }

    private Map<String, String> addPrefixToKeys(Map<String, String> map, String prefix) {
        return map.entrySet().stream()
                .collect(java.util.stream.Collectors.toMap(entry -> prefix + entry.getKey(), Map.Entry::getValue));
    }

    public String toCsv(List<Map<String, Object>> dataList) throws IOException {
        StringWriter writer = new StringWriter();

        if (dataList != null && !dataList.isEmpty()) {
            Map<String, Object> firstMap = dataList.get(0);
            Set<String> columnNames = firstMap.keySet();

            CsvSchema schema = CsvSchema.builder()
                    .addColumns(columnNames, CsvSchema.ColumnType.STRING)
                    .build()
                    .withHeader();

            for (Map<String, Object> data : dataList) {
                csvMapper.writer(schema).writeValue(writer, data);
            }
        }

        return writer.toString();
    }
}