package com.example.emissions;

import com.example.emissions.model.DataRepository;
import com.example.emissions.model.LocationData;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.HashMap;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@DataMongoTest
@ActiveProfiles("test")
public class FindLocationTest {

    @Autowired
    private DataRepository dataRepository;

    @Test
    public void testFindLocationByName() {
//        String name = "name";
//        LocationData locationData = new LocationData(name, "iso", false, new HashMap<>());
//        dataRepository.save(locationData);
//
//        LocationData foundLocation = dataRepository.findLocationByName(name);
//        assertThat(foundLocation).isNotNull();
//        assertThat(foundLocation.getName()).isEqualTo(name);
    }

    @Test
    public void testFindLocationByISO() {
//        String iso = "iso";
//        LocationData locationData = new LocationData("name", iso, false, new HashMap<>());
//        dataRepository.save(locationData);
//
//        LocationData foundLocation = dataRepository.findLocationByISO(iso);
//        assertThat(foundLocation).isNotNull();
//        assertThat(foundLocation.getISO()).isEqualTo(iso);
    }
}
