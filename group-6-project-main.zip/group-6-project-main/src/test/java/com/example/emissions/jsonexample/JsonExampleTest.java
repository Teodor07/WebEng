package com.example.emissions.jsonexample;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class JsonExampleTest {
    @Test
    public void testJsonExample() throws IOException {
//        String jsonPath = System.getProperty("user.dir") + "/src/test/java/com/example/emissions/jsonexample/example.json";
//
//        ObjectMapper objectMapper = new ObjectMapper();
////        JsonExample jsonExample = objectMapper.readValue(new File(jsonPath), JsonExample.class);
//        Map<String, String> resultMap = objectMapper.readValue(new File(jsonPath), new TypeReference<Map<String, String>>() {});
//
////        Map<String, String> map = jsonExample.getMap();
//
//        assertThat(resultMap).isNotNull();
//
//        System.out.println(resultMap.keySet());
    }
}
