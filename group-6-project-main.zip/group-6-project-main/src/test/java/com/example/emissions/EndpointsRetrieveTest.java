package com.example.emissions;

import com.example.emissions.endpoints.EndpointsRetrieve;
import com.example.emissions.model.DataRepository;
import com.example.emissions.model.LocationData;
import com.example.emissions.model.YearData;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@DataMongoTest
@ActiveProfiles("test")
public class EndpointsRetrieveTest {
    @Test
    public void testGetPopulationGDPData() {
//        DataRepository mockRepository = mock(DataRepository.class);
//
//        EndpointsRetrieve endpointsRetrieve = new EndpointsRetrieve(mockRepository);
//
//        String countryISO = "NLD";
//        int year = 2000;
//
//        YearData mockYearData = new YearData(1, 1, 1, 1, 1, 1, 1, 1);
//        Map<Integer, YearData> yearMap = new HashMap<>();
//        yearMap.put(year, mockYearData);
//        LocationData mockLocationData = new LocationData("Netherlands", "NLD", false, yearMap);
//
//        when(mockRepository.findLocationByISO(countryISO)).thenReturn(mockLocationData);
//
//        ResponseEntity<Map<String, Object>> response = endpointsRetrieve.getPopulationGDPData(countryISO, year);
//
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//
//        Map<String, Object> responseBody = response.getBody();
//        assertNotNull(responseBody);
//        System.out.println(responseBody.get("population"));
    }
}