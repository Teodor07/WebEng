package com.example.emissions;


import com.example.emissions.model.DataRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@DataMongoTest
@ActiveProfiles("test")
public class ReadJSONTest {
    @Test
    public void testReadJSON() {
//        DataRepository dataRepository = Mockito.mock(DataRepository.class);
//        InitializeDB initializeDB = new InitializeDB(dataRepository);
//        initializeDB.readJSON();
//        assertThat(dataRepository.findAll()).isNotNull();
    }
}
