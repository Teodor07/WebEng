# Group 6 Project ReadME

Please go to the /Documentation/APIdocumentation.md to see the API documentation, and the documentation for the software
