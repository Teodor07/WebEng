# Backend
To create the backend endpoints we use the Spring Framework.
The backend is hosted on port 8080.

# Database
For persistency we use Mongodb.
The database is hosted on port 27017.

# Frontend
For the frontend we use the React frontend with Typescript.
The frontend is hosted on port 3000.

# Bonus